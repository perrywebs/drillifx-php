<?php
// Central MySQL configuration (Herd / phpMyAdmin environment).
// phpMyAdmin: http://phpmyadmin.test (host 127.0.0.1, port 3308, user root)
return [
    'host' => '127.0.0.1',
    'port' => 3308,
    'db'   => 'drillifx',
    'user' => 'root',
    'pass' => 'secret',
    'charset' => 'utf8mb4',
];
